package com.upgrad.ims;

public class Main extends Ticket {

    private static Object Ticket;

    public static void main(String[] args) {
        Passenger p = new Passenger();
        Contact c = new Contact();

            p.setId("1");
            p.setAddress("");
            p.setPnr("P123");



        System.out.println(p.getId());
        System.out.println(p.getPnr());

    }
}
