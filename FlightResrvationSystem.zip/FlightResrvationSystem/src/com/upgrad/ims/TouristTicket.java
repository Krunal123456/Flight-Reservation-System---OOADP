package com.upgrad.ims;

public class TouristTicket extends Ticket{
    String hotelAddress;


    public String getHotelAddress() {
        return hotelAddress;
    }

    public void setHotelAddress(String hotelAddress) {
        this.hotelAddress = hotelAddress;
    }

    public String getSelectedTouristLocation() {
        return selectedTouristLocation;
    }

    public void setSelectedTouristLocation(String selectedTouristLocation) {
        this.selectedTouristLocation = selectedTouristLocation;
    }

    String selectedTouristLocation;
}
