package com.upgrad.ims;

public class Flight {
    String FlightNumber;
    String AirLine;
    int Capacity;
    private int BookedSeats;


    public String getFlightNumber() {
        return FlightNumber;
    }

    public void setFlightNumber(String flightNumber) {
        FlightNumber = flightNumber;
    }

    public String getAirLine() {
        return AirLine;
    }

    public void setAirLine(String airLine) {
        AirLine = airLine;
    }

    public int getCapacity() {
        return Capacity;
    }

    public void setCapacity(int capacity) {
        Capacity = capacity;
    }

    public int getBookedSeats() {
        return BookedSeats;
    }

    public void setBookedSeats(int bookedSeats) {
        BookedSeats = bookedSeats;
    }

    public String getSeatDetails() {
        return seatDetails;
    }

    public void setSeatDetails(String seatDetails) {
        this.seatDetails = seatDetails;
    }

    public boolean isCheckavailability() {
        return checkavailability;
    }

    public void setCheckavailability(boolean checkavailability) {
        this.checkavailability = checkavailability;
    }

    String seatDetails;
    boolean checkavailability;

}
