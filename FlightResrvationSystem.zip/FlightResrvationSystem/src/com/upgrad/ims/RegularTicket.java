package com.upgrad.ims;

public class RegularTicket extends Ticket {
    String SpecialServices;



    public String getSpecialServices() {
        return SpecialServices;
    }

    public void setSpecialServices(String specialServices) {
        SpecialServices = specialServices;
    }
}
