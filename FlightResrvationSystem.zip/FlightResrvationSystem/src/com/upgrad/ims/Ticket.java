package com.upgrad.ims;
public abstract class Ticket extends Flight {

    String pnr;
    String from;
    String to;
    Flight flight;
    String ArriveDateTime;
    String DepartureDateTime;
    private Passenger passenger;
    String SeatNumber;
    Float Price;
    boolean cancelled;
    String checkStatus;
    String FlightDuration;



    public String getPnr() {
        return pnr;
    }

    public void setPnr(String pnr) {
        this.pnr = pnr;
    }


    public String getFrom() {
        return from;
    }

    public void setFrom(String from) {
        this.from = from;
    }

    public String getTo() {
        return to;
    }

    public void setTo(String to) {
        this.to = to;
    }

    public Flight getFlight() {
        return flight;
    }

    public void setFlight(Flight flight) {
        this.flight = flight;
    }

    public String getArriveDateTime() {
        return ArriveDateTime;
    }

    public void setArriveDateTime(String arriveDateTime) {
        ArriveDateTime = arriveDateTime;
    }

    public String getDepartureDateTime() {
        return DepartureDateTime;
    }

    public void setDepartureDateTime(String departureDateTime) {
        DepartureDateTime = departureDateTime;
    }

    public Passenger getPassanger() {
        return passenger;
    }

    public void setPassanger(Passenger passenger) {
        this.passenger = passenger;
    }

    public String getSeatNumber() {
        return SeatNumber;
    }

    public void setSeatNumber(String seatNumber) {
        SeatNumber = seatNumber;
    }

    public Float getPrice() {
        return Price;
    }

    public void setPrice(Float price) {
        Price = price;
    }

    public boolean isCancelled() {
        return cancelled;
    }

    public void setCancelled(boolean cancelled) {
        this.cancelled = cancelled;
    }

    public String getCheckStatus() {
        return checkStatus;
    }

    public void setCheckStatus(String checkStatus) {
        this.checkStatus = checkStatus;
    }

    public String getFlightDuration() {
        return FlightDuration;
    }

    public void setFlightDuration(String flightDuration) {
        FlightDuration = flightDuration;
    }


}
