package com.upgrad.ims;
 public class Passenger extends Ticket {
    java.lang.String id;
    Address address;
    java.lang.String getCount;
    Contact contact;
    private static int idCounter;




     public static int getIdCounter() {
         return idCounter;
     }

     public static void setIdCounter(int idCounter) {
         Passenger.idCounter = idCounter;
     };



     public void setGetCount(java.lang.String getCount) {
         this.getCount = getCount;
     }

     private Address String;

     public java.lang.String getGetCount() {
         return getCount;
     }

     public java.lang.String getId() {
        return id;
    }

    public void setId(java.lang.String id) {
        this.id = id;
    }

    public Address getAddress() {
        return address;
    }

    public void setAddress(String address) {
         this.address = String;
    }

    public Contact getContact() {
        Contact contact = this.contact;
        return contact;
    }

    public void setContact(Contact contact) {
        this.contact = contact;
    }



 }
